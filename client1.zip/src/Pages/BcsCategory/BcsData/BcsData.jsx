import Prili from '../../../Components/Prili/Prili';

const BcsData = ({ data, category }) => {
	//   const { category } = useParams();
	//   console.log(category);
	return (
		<div>
			<Prili data={data} />
		</div>
	);
};

export default BcsData;
