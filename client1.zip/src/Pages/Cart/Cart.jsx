import React from "react";
import CartPageSection from "./CartPageSection/CartPageSection";

const Cart = () => {
  return (
    <div>
      <CartPageSection></CartPageSection>
    </div>
  );
};

export default Cart;
