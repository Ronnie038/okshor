import React from 'react';

const LogOut = () => {
    return (
        <div>
            <h1>Log OUt</h1>
        </div>
    );
};

export default LogOut;