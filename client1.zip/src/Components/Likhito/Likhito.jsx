import React from "react";

const Likhito = () => {
  return <div>Likhito</div>;
};

export default Likhito;
